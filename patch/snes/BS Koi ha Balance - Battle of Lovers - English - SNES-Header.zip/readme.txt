########################################################################################

This is the English translation for Koi wa Balance - Battle of Lovers
a.k.a Koi wa Balance: Tatoeba K-kun no Tabou na Ichinichi Hen
released in 1996 for the Satellaview extension of the Super Famicom
and developped by Squaresoft.

Current version : 1.0.

It applies to the following ROM :
File: BS Koi ha Balance - Battle of Lovers (J)
No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: 6D687F7B6C7C82C479E52459B7C8E1C8955FC9F5
File/ROM CRC32: 60293E16

------------------------------- THE GAME -------------------------------

This is a party game for up to 4 players in which you play as
one of four brothers who are competing in a challenge set up
by their dying grand-father, head of the family business.
They have to roam the city, pick up girls and take them on dates.
The player who gets the most kisses by the end of the game is the
new heir of the company.

Despite this weird premise, the game has no sexual content beyond
a few innuendos. The main screen says "players 6 and older".


--------------------------- THE TRANSLATION ----------------------------
Find more information about the translation and the game :
https://github.com/Krokodyl/koi-wa-balance

Feel free to contribute and improve/fix any issues.


                                                           Cheers,
                                                           Krokodyl
########################################################################################